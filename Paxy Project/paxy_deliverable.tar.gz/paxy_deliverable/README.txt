# Paxy deliverable

Every separate compressed file contains a different branch from our github repo. 
Every branch has changes over the master branch (vanilla_paxos.zip) corresponding to each experiment.
The master branch is just the provided code completed to make it work.

We don't include a branch for the second experiment as we had to just comment a couple of lines.

- Miguel Cruz
- Riccardo Cecco
- Javier Cano